var app = angular.module("puzzle", []);

app.controller("homeCntrl", function ($scope, $http, $timeout) {
    $scope.pnm = "Puzzle";
    $scope.lastName = "Doe";

    $scope.getTeams = function () {

        var Indata = $.param({ 'requesttype': 'GETTEAMS' });
        var config = {
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded;charset=utf-8;'
            }
        }
        $http.post("http://projectslabs.in/plantation/promotergamer.php", Indata, config).then(function (response) {
            var getData = response.data;
            if (getData.result.length > 0) {
                $scope.getTeamMessage = getData.result;
                $scope.msgflag = false;
            }
            else {
                $scope.getTeamMessage = "Nothing Found Create your own team and start.";
                $scope.msgflag = true;
            }

        });
    }

    $scope.getPlayGroundData = function () {

        var Indata = $.param({ 'requesttype': 'GETPLAYERDATA' , 'pid': 1});
        var config = {
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded;charset=utf-8;'
            }
        }
        $http.post("http://projectslabs.in/plantation/promotergamer.php", Indata, config).then(function (response) {
            var getData = response.data;
            if (getData.result.length > 0) {
                $scope.getTeamMessage = getData.result;
                $scope.msgflag = false;
            }
            else {
                $scope.getTeamMessage = "Nothing Found Create your own team and start.";
                $scope.msgflag = true;
            }

        });
    }
    $scope.getPlayGroundData();

    $scope.getTeams();

    $scope.addTeam = function () {
        if (!isTeam($scope.getTeamMessage, $scope.teamname)) {
            $scope.tflag = false;
            $scope.resultflag = false;
            $scope.addresult = ""
            var Indata = $.param({ 'requesttype': 'ADDTEAM', 'tname': $scope.teamname, 'rcount': $scope.teamcount });
            var config = {
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded;charset=utf-8;'
                }
            }
            $http.post("http://projectslabs.in/plantation/promotergamer.php", Indata, config).then(function (response) {
                var getData = response.data;
                $scope.addresult = getData.result[0];
                $scope.resultflag = true;
                $scope.getTeams();
            });
        } else {
            $scope.tflag = true;
        }
    }

    $scope.addPlayer = function () {
        $scope.resultflag = false;
        var Indata = $.param({ 'requesttype': 'ADDPLAYER', 'pname': $scope.playername, 'tid': $scope.tid, 'tname': $scope.tname });
        var config = {
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded;charset=utf-8;'
            }
        }
        $http.post("http://projectslabs.in/plantation/promotergamer.php", Indata, config).then(function (response) {
            var getData = response.data;
            $scope.addresult = getData.result[0];
            $scope.pnm = $scope.playername

            $scope.resultflag = true;
        });

    }

    isTeam = function (inArray, val) {
        var res = false;
        for (var i = 0; i < inArray.length; i++) {
            if (inArray[i].teamname.indexOf(val) !== -1)
                return true;
        }
        return res;
    }

    $scope.joinbtn = function (val) {
        $scope.addresult = "";
        $scope.popmessage = "Player name: ";
        $scope.tid = $scope.getTeamMessage[val].tid;
        $scope.tname = $scope.getTeamMessage[val].teamname;
        $scope.playerflag = true;
        $scope.teamflag = false;
    }

    $scope.createbtn = function () {
        $scope.addresult = "";
        $scope.popmessage = "Team details: ";
        $scope.playerflag = false;
        $scope.teamflag = true;
    }

    $scope.roleFlag = false;
    $scope.startCounter = function () {
        $scope.counter = 0;
        if ($scope.roleFlag) {
            $scope.roleFlag = false;
            stopCounter();
        } else {
            $scope.roleFlag = true;
            updateCounter();
        }
        
    }
    var timer;
    $scope.counter = 0;
    var stopCounter = function () {
        $timeout.cancel(timer);
    };
    var updateCounter = function () {
        $scope.counter++;
        stopCounterAt(5);
        timer = $timeout(updateCounter, 1000);
    };

    var stopCounterAt = function(counts){
        if($scope.counter == counts){
            $scope.roleFlag = false;
            stopCounter();
        }
    }


});

app.value('sessionService', {
    clear: function() {
      this.cart = new Cart();
      // mechanism to create the cart id 
      this.cart.cartId = 1;
    },
    save: function(session) {
      this.cart = session.cart;
    },
    updateCart: function(productId, productQty) {
      this.cart.cartItem.push({
        'productId': productId,
        'productQty': productQty
      });
    },
  //delete Item and other cart operations function goes here...
  });

  window.addCart = function($scope, $http, $window, $document){
  
    var getValue = function(){
        return $window.sessionStorage.length;
    }
      
    var getData = function(){
      var json = [];
      $.each($window.sessionStorage, function(i, v){
        json.push(angular.fromJson(v));
      });
      return json;
    }
      
    $scope.images = getData();
    $scope.count = getValue();
  
    $scope.addItem = function(id){
        var image = document.getElementById('img'+id);
        json = {
          id: id,
          img: image.src
        }
        $window.sessionStorage.setItem(id, JSON.stringify(json));
        $scope.count = getValue();
        $scope.images = getData();
    }
    
    $scope.removeItem = function(id){
      $window.sessionStorage.removeItem(id);
      $document.
      $scope.count = getValue();
      $scope.images = getData();
      alert('Removed with Success!');
    }
}